<?php
//Khai báo sử dụng session
session_start();
 
//Khai báo utf-8 để hiển thị được tiếng việt
header('Content-Type: text/html; charset=UTF-8');
 
//Xử lý đăng nhập

    //Kết nối tới database
    include('connection.php');
     
    //Lấy dữ liệu nhập vào
    $user = addslashes($_POST['user']);
    $password = addslashes($_POST['pass']);
    $confirm_pass = addslashes($_POST['confirm_pass']);
    $lastName = addslashes($_POST['lastName']);
    $phone = addslashes($_POST['phone']);
    
    //Kiểm tra tên đăng nhập có tồn tại không
    if ($password == $confirm_pass) {
    $query = sqlsrv_query($conn, "INSERT INTO account
           (username
           ,pass
           ,lastname
           ,phone
           ,seller
           ,admin)
     VALUES
           ('$user'
           ,'$password'
           ,N'$lastName'
           ,'$phone'
           ,'0'
           ,'0')
    ");
    if ($query) {
        header("Location: ../Login.php");
        }
    }else{
        $_SESSION['mess1'] = "mật khẩu không trùng khớp";
        header("Location: ../signup.php");
    }
?>